package chatRobot;
import java.awt.event.*;
import javax.swing.JTextArea;
public class MyKeyEvent extends KeyAdapter{
	JTextArea text;
	Robot robot = new Robot();
	String str;
	String[] temp;
	MyKeyEvent(JTextArea text){
		this.text = text;
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		super.keyPressed(e);
		if(e.getKeyCode()==KeyEvent.VK_ENTER) {
			str = text.getText();
			temp = str.split(":");
			str=temp[temp.length-1];
			str=robot.getRespond(str);
			text.append("\n回复:"+str+"\n我说:");
		}
	}
}


