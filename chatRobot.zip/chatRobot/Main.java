package chatRobot;
import javax.swing.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	View text = new View();
	JFrame window = new JFrame("chat with rebot");
	Robot robot = new Robot();
	window.setBounds(600,400,300,600);
	window.setContentPane(text.panel);
	window.setVisible(true);
	window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
