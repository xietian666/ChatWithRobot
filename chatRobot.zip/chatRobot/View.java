package chatRobot;
import java.awt.Color;
import java.awt.Font;

import javax.swing.*;

public class View {
	JPanel panel = new JPanel();
	JTextArea text = new JTextArea(25 ,20);
	View(){
		text.setLineWrap(true);
		text.setForeground(Color.BLACK);
		text.setBackground(Color.WHITE);
		text.setFont(new Font(null,Font.BOLD,14));
		text.addKeyListener(new MyKeyEvent(text));
		text.append("我说:");
		JScrollPane scroll = new JScrollPane(text);
		panel.add(scroll);
	}
}
